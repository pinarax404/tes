const fs = require('fs');
const { prompt } = require('./src/prompt.js');
const { igCreate } = require('./src/instagramCreate.js');

if (!fs.existsSync('../storage/downloads/hasil_akun_ig.txt')) {fs.appendFileSync('../storage/downloads/hasil_akun_ig.txt', '')};
if (!fs.existsSync('../storage/downloads/bio_text.txt')) {fs.appendFileSync('../storage/downloads/bio_text.txt', '')};
if (!fs.existsSync('../storage/downloads/bio_link.txt')) {fs.appendFileSync('../storage/downloads/bio_link.txt', '')};
if (!fs.existsSync('../storage/downloads/akun_target.txt')) {fs.appendFileSync('../storage/downloads/akun_target.txt', '')};

process.stdout.write('\033c');

const create = async (modeCreate, modeAgent) => {
    const startCreate = await igCreate(modeCreate, modeAgent);
    if (startCreate !== false) {
        console.log(startCreate);
    } else {
        create(modeCreate, modeAgent);
    }
}


(async () => {
    const mode = await prompt();
    create(mode.modeCreate, mode.modeAgent);
})();